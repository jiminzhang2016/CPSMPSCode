addpath('.\DCTR');
payloads = [0.1, 0.2, 0.3, 0.4];
index = 0;

testValue = [0.5,1];

      
%makeFeature(2000,75, ['F:\CodeForPaper3\fullbase75\\bow75Random2000\'], ['F:\CodeForPaper3\fullbase75\\bow75Random2000\cover.mat']);
%my_GFR(['F:\CodeForPaper3\fullbase75\\bow75Random2000\'], ['F:\CodeForPaper3\fullbase75\\bow75Random2000\gfrcover.mat'], 75)

index = 0;
parray = [0,0.5,0.5,1];
testValue = [0.5,1];
for jj=4:-1:1
    payload = payloads(jj);
    %payload = 0.4;
    testP = parray(jj);
    
    
   
        N = 20;
        maxValue = 4;
        dist = [];
        foldName = ['CPSMPSASPR\','payload=', num2str(payload),'p = ',num2str(testP)];
        %foldName = ['li65',num2str(N), 'p = ',num2str(p),'maxT=', num2str(4), 'rho=', num2str(1.5), 'beta=', num2str(1),'payload=', num2str(payload)];
        for i = 1:10000
            coverName = ['.\random2000\',num2str(i),'.jpg'];
            pngName = ['.\random2000Predict\'];
            %pngName = 'E:\imageSetpaper3\fullbase\\';
            stegoLiName = ['.\stegoPath\',foldName,'\', num2str(i),'.jpg'];

            if(exist(coverName, 'file')>0 && exist([pngName, num2str(i), '.png'], 'file')>0)

                if(exist(['.\stegoPath\\',foldName,'\'], 'dir')==0)
                    mkdir(['.\stegoPath\\',foldName,'\']);
                end
                %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
                %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
               if(exist(stegoLiName, 'file')==0)
                    stegoLiName
                    pvalue = dicidep85bossABSDDPR(coverName, stegoLiName, payload, 1, i, testP, 123456, pngName, N, maxValue, 0.2, 1.5, 1, num2str(i), 'testrecord2182qf852new2.txt',2);
                    %embeddingWithPredictNoLogNewCostdot65(coverName, stegoLiName, payload, 1, i, testP, 123456, pngName);
                    PSMPS_AS(coverName, stegoLiName, payload, 1, i, testP, 123456, pngName, N, maxValue, 0.2, 1.5, 1, num2str(i), 'testrecord2182qf852new2.txt',2);
                end
            end
        end
end

