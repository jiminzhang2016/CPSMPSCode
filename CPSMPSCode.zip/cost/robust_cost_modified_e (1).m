function [cost_plus1,cost_minus1] = robust_cost_modified_e(img_name,a)
jpeg_old = jpeg_read(img_name);
jpeg_coef = jpeg_old.coef_arrays{1};
jpeg_size = size(jpeg_coef);
cost_plus1 = zeros(jpeg_size);
cost_minus1 = zeros(jpeg_size);
fun = @(x)x.data .*jpeg_old.quant_tables{1};
I_spatial = blockproc(jpeg_old.coef_arrays{1},[8 8],fun);
fun=@(x)idct2(x.data);
I_spatial = blockproc(I_spatial,[8 8],fun)+128;
C_QUANT = jpeg_old.quant_tables{1};
spatialImpact = cell(8, 8);
minV = 0+a;
maxV = 255-a;
for bcoord_i=1:8
    for bcoord_j=1:8
        testCoeffs = zeros(8, 8);
        testCoeffs(bcoord_i, bcoord_j) = 1;
        spatialImpact{bcoord_i, bcoord_j} = idct2(testCoeffs)*C_QUANT(bcoord_i, bcoord_j);
    end
end
for i=1:8:jpeg_size(1)
    for j=1:8:jpeg_size(2)
        dct_block = I_spatial(i:i+7,j:j+7);
        for ii=1:8
            for jj=1:8
                img_content = dct_block + spatialImpact{ii,jj};
                img_content_bellow_0 = minV - img_content;
                img_content_bellow_0(img_content_bellow_0<0) = 0;
                img_cost_bellow_0 = sum(img_content_bellow_0(:).^2);
                img_content_above_255 = img_content - maxV;
                img_content_above_255(img_content_above_255<0) = 0;
                img_cost_above_255 = sum(img_content_above_255(:).^2);
                cost_block(ii,jj) = sqrt(img_cost_above_255+img_cost_bellow_0);
            end
        end
        cost_plus1(i:i+7,j:j+7) = cost_block;
        for ii=1:8
            for jj=1:8
                img_content = dct_block - spatialImpact{ii,jj};
                img_content_bellow_0 = minV - img_content;
                img_content_bellow_0(img_content_bellow_0<0) = 0;
                img_cost_bellow_0 = sum(img_content_bellow_0(:).^2);
                img_content_above_255 = img_content - maxV;
                img_content_above_255(img_content_above_255<0) = 0;
                img_cost_above_255 = sum(img_content_above_255(:).^2);
                cost_block(ii,jj) = sqrt(img_cost_above_255+img_cost_bellow_0);
            end
        end
        cost_minus1(i:i+7,j:j+7) = cost_block;
    end
end


end
        