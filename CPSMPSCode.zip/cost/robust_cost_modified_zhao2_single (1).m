function [cost_plus1,cost_minus1] = robust_cost_modified_zhao2_single(img_name,rhoP1J,rhoM1J,a,p1p,m1p,h,msg,srcq,dstq,seed,rand_path)
wetConst = 10^13;
jpeg_old = jpeg_read(img_name);
jpeg_coef = jpeg_old.coef_arrays{1};
real_coef = jpeg_coef;
jpeg_size = size(jpeg_coef);
cost_plus1 = zeros(jpeg_size);
cost_minus1 = zeros(jpeg_size);
fun = @(x)x.data .*jpeg_old.quant_tables{1};
I_spatial = blockproc(jpeg_old.coef_arrays{1},[8 8],fun);
fun=@(x)idct2(x.data);
I_spatial = blockproc(I_spatial,[8 8],fun)+128;
C_QUANT = jpeg_old.quant_tables{1};
spatialImpact = cell(8, 8);
for bcoord_i=1:8
    for bcoord_j=1:8
        testCoeffs = zeros(8, 8);
        testCoeffs(bcoord_i, bcoord_j) = 1;
        dct_block = testCoeffs*C_QUANT(bcoord_i, bcoord_j);
        spatialImpact{bcoord_i, bcoord_j} = idct2(dct_block);
    end
end
for i=1:8:jpeg_size(1)
    for j=1:8:jpeg_size(2)
        dct_block = I_spatial(i:i+7,j:j+7);
        dct_block_debug = jpeg_coef(i:i+7,j:j+7);
        for ii=1:8
            for jj=1:8
                img_content = dct_block + spatialImpact{ii,jj};
                img_content_bellow_0 = 0 - img_content;
                img_content_bellow_0(img_content_bellow_0<0) = 0;
                img_cost_bellow_0 = sum(img_content_bellow_0(:));
                img_content_above_255 = img_content - 255;
                img_content_above_255(img_content_above_255<0) = 0;
                img_cost_above_255 = sum(img_content_above_255(:));
                cost_block(ii,jj) = img_cost_above_255+img_cost_bellow_0;
            end
        end
        
        %{
        if(nnz(cost_block)>0)
            cost_plus1(i:i+7,j:j+7)= wetConst;
        end  
        %}
        cost_plus1(i:i+7,j:j+7)=cost_block;
        for ii=1:8
            for jj=1:8
                img_content = dct_block - spatialImpact{ii,jj};
                img_content_bellow_0 = 0 - img_content;
                img_content_bellow_0(img_content_bellow_0<0) = 0;
                img_cost_bellow_0 = sum(img_content_bellow_0(:));
                img_content_above_255 = img_content - 255;
                img_content_above_255(img_content_above_255<0) = 0;
                img_cost_above_255 = sum(img_content_above_255(:));
                cost_block(ii,jj) = img_cost_above_255+img_cost_bellow_0;
            end
        end
        cost_minus1(i:i+7,j:j+7)=cost_block;
        %{
        if(nnz(cost_block)>0)
           cost_minus1(i:i+7,j:j+7) = wetConst;
        end  
        %}
    end
end
index = 1;
minV = inf;
while(true)
    cost_plus1_array(index,:,:) = cost_plus1;%������ȡ���ʵ�³������
    cost_minus1_array(index,:,:) = cost_minus1;
    jpeg_y = jpeg_old.coef_arrays{1};
    size_ = size(jpeg_y);
    cover_len = size_(1) * size_(2);
    %rhoP1 = rhoP1J./ (1./(1+a * cost_plus1));
    %rhoM1 = rhoM1J./ (1./(1+a * cost_minus1));
    rhoP1 = rhoP1J + wetConst * cost_plus1;
    rhoM1 = rhoM1J + wetConst * cost_minus1;
    diff_num = jcrisbe_embed(img_name,rhoP1,rhoM1,cost_plus1,cost_minus1,p1p,m1p,h,msg,srcq,dstq,'middle.jpg',rand_path);
    stego_real = (jpeg_read('middle.jpg'));
    stego_real = stego_real.coef_arrays{1};
    diff = stego_real - real_coef;
    cost_plus12 = zeros(jpeg_size);
    cost_minus12 = zeros(jpeg_size);
    for i=1:8:jpeg_size(1)
        for j=1:8:jpeg_size(2)
            dct_block = stego_real(i:i+7,j:j+7);
            diff_block = diff(i:i+7,j:j+7); 
            if(sum(abs(diff_block(:)))>0)
                debug=1;
            end
            block_content = idct2(dct_block.*C_QUANT)+128;
            img_content_bellow_0 = 0 - block_content;
            img_content_bellow_0(img_content_bellow_0<0) = 0;
            img_cost_bellow_0 = sum(img_content_bellow_0(:));
            img_content_above_255 = block_content - 255;
            img_content_above_255(img_content_above_255<0) = 0;
            img_cost_above_255 = sum(img_content_above_255(:));
            cost_block = img_cost_above_255+img_cost_bellow_0;
            for ii=1:8
                for jj=1:8
                    if(diff_block(ii,jj)==1)
           
                        cost_block_plus(ii,jj) = cost_block;
                    else
                        cost_block_plus(ii,jj) = 0;
                    end
                    if(diff_block(ii,jj)==-1)
                 
                        cost_block_minus(ii,jj) = cost_block;
                    else
                        cost_block_minus(ii,jj) = 0;
                    end
                end
            end
            %{
            if(nnz(cost_block_plus)>0)
                cost_plus12(i:i+7,j:j+7) = wetConst;
            end
            if(nnz(cost_block_minus)>0)
                cost_minus12(i:i+7,j:j+7) = wetConst;
            end
            %}
            
            cost_plus12(i:i+7,j:j+7) = cost_block_plus;
            cost_minus12(i:i+7,j:j+7) = cost_block_minus;
        end
    end
    if(sum(cost_plus12(:))==0 && sum(cost_minus12(:))==0 )
        return;
    end
    %sum(cost_plus12(:))
    %sum(cost_minus12(:))
    sum_error(index) = sum(cost_plus12(:)) + sum(cost_minus12(:));
    num_error(index) = (diff_num);
    if(sum_error(index) < minV)
        minV_index = index;
        minV = sum_error(index);
    end
    if(index == 10)
        %cost_plus1 = reshape(cost_plus1_array(minV_index,:,:),jpeg_size);
        %cost_minus1 = reshape(cost_minus1_array(minV_index,:,:),jpeg_size);
        return;
    end
    index = index + 1;
    cost_plus1(cost_plus1==0) = cost_plus1(cost_plus1==0) + cost_plus12(cost_plus1==0); %����cost_plus1
    cost_minus1(cost_plus1==0) = cost_minus1(cost_plus1==0) + cost_minus12(cost_plus1==0);%����cost_minus1
end
end
        