function [cost_plus1,cost_minus1] = robust_cost_modified_zhao2_tenary_modified(img_name,rhoP1J,rhoM1J,a,p1p,m1p,h,msg,srcq,dstq,seed,rand_path)
wetConst = 10^13;
jpeg_old = jpeg_read(img_name);
jpeg_coef = jpeg_old.coef_arrays{1};
real_coef = jpeg_coef;
jpeg_size = size(jpeg_coef);
cost_plus1 = zeros(jpeg_size);
cost_minus1 = zeros(jpeg_size);
fun = @(x)x.data .*jpeg_old.quant_tables{1};
I_spatial = blockproc(jpeg_old.coef_arrays{1},[8 8],fun);
fun=@(x)idct2(x.data);
I_spatial = blockproc(I_spatial,[8 8],fun)+128;
C_QUANT = jpeg_old.quant_tables{1};
spatialImpact = cell(8, 8);
for bcoord_i=1:8
    for bcoord_j=1:8
        testCoeffs = zeros(8, 8);
        testCoeffs(bcoord_i, bcoord_j) = 1;
        dct_block = testCoeffs*C_QUANT(bcoord_i, bcoord_j);
        spatialImpact{bcoord_i, bcoord_j} = idct2(dct_block);
    end
end
for i=1:8:jpeg_size(1)
    for j=1:8:jpeg_size(2)
        dct_block = I_spatial(i:i+7,j:j+7);
        dct_block_debug = jpeg_coef(i:i+7,j:j+7);
        for ii=1:8
            for jj=1:8
                img_content = dct_block + spatialImpact{ii,jj};
                img_content_bellow_0 = 0 - img_content;
                img_content_bellow_0(img_content_bellow_0<0) = 0;
                img_cost_bellow_0 = sum(img_content_bellow_0(:));
                img_content_above_255 = img_content - 255;
                img_content_above_255(img_content_above_255<0) = 0;
                img_cost_above_255 = sum(img_content_above_255(:));
                cost_block(ii,jj) = img_cost_above_255+img_cost_bellow_0;
            end
        end
        cost_plus1(i:i+7,j:j+7)=cost_block;
        for ii=1:8
            for jj=1:8
                img_content = dct_block - spatialImpact{ii,jj};
                img_content_bellow_0 = 0 - img_content;
                img_content_bellow_0(img_content_bellow_0<0) = 0;
                img_cost_bellow_0 = sum(img_content_bellow_0(:));
                img_content_above_255 = img_content - 255;
                img_content_above_255(img_content_above_255<0) = 0;
                img_cost_above_255 = sum(img_content_above_255(:));
                cost_block(ii,jj) = img_cost_above_255+img_cost_bellow_0;
            end
        end
        cost_minus1(i:i+7,j:j+7)=cost_block;
    end
end
index = 1;
minV = inf;
while(true)
    cost_plus1_array(index,:,:) = cost_plus1;%������ȡ���ʵ�³������
    cost_minus1_array(index,:,:) = cost_minus1;
    jpeg_y = jpeg_old.coef_arrays{1};
    size_ = size(jpeg_y);
    cover_len = size_(1) * size_(2);
    rhoP1 = rhoP1J + a * cost_plus1;
    rhoM1 = rhoM1J + a * cost_minus1;;
    
    diff_num = jcrisbe_embed_tenary(img_name,rhoP1,rhoM1,cost_plus1,cost_minus1,p1p,m1p,h,msg,srcq,dstq,[seed,'middle.jpg'],rand_path,seed);
    stego_real = (jpeg_read([seed,'middle.jpg']));
    stego_real = stego_real.coef_arrays{1};
    diff = stego_real - real_coef;
    cost_plus12 = zeros(jpeg_size);
    cost_minus12 = zeros(jpeg_size);
    total_cost = 0;
    for i=1:8:jpeg_size(1)
        for j=1:8:jpeg_size(2)
            dct_block = stego_real(i:i+7,j:j+7);
            diff_block = diff(i:i+7,j:j+7); 
            spatial_block = I_spatial(i:i+7,j:j+7);
            block_content = idct2(dct_block.*C_QUANT)+128;
            block_cost_plus1 = cost_plus1(i:i+7,j:j+7);
            block_cost_minus1 = cost_minus1(i:i+7,j:j+7);
            cost_plus12(i:i+7,j:j+7) = block_cost_plus1;
            cost_minus12(i:i+7,j:j+7) = block_cost_minus1;
            img_content_bellow_0 = 0 - block_content;
            img_content_bellow_0(img_content_bellow_0<0) = 0;
            img_cost_bellow_0 = sum(img_content_bellow_0(:));
            img_content_above_255 = block_content - 255;
            img_content_above_255(img_content_above_255<0) = 0;
            img_cost_above_255 = sum(img_content_above_255(:));
            cost_block = img_cost_above_255+img_cost_bellow_0;
            total_cost = total_cost + cost_block;
            if( ~(nnz(diff_block)>=2 && cost_block>0))
                continue;
            end
            cost_stego = zeros(1,64);
            for i_i = 1:64
                if diff_block(i_i) ~= 0
                    if(diff_block(i_i) == 1)
                        cost_stego(i_i) = block_cost_plus1(i_i);
                    else
                        cost_stego(i_i) = block_cost_minus1(i_i);
                    end
                else
                    cost_stego(i_i) = 0;
                end
            end
        
            [sorted_cost_stego,sorted_pos] = sort(cost_stego);
            for i_i=1:64
                spatial_block_cp = spatial_block;
                if(diff_block(sorted_pos(i_i))~=0)
                    for j_j=1:i_i
                        if(diff_block(sorted_pos(j_j))==1)
                            spatial_block_cp =  spatial_block_cp  + spatialImpact{sorted_pos(j_j)};
                        end
                        if(diff_block(sorted_pos(j_j))==-1)
                            spatial_block_cp =  spatial_block_cp  - spatialImpact{sorted_pos(j_j)};
                        end
                    end
                    img_content_bellow_0 = 0 - spatial_block_cp;
                    img_content_bellow_0(img_content_bellow_0<0) = 0;
                    img_cost_bellow_0 = sum(img_content_bellow_0(:));
                    img_content_above_255 = spatial_block_cp - 255;
                    img_content_above_255(img_content_above_255<0) = 0;
                    img_cost_above_255 = sum(img_content_above_255(:));
                    new_cost = img_cost_above_255+img_cost_bellow_0; 
                    cost_stego(sorted_pos(i_i)) = new_cost; 
                end
            end
            %���´��ۺ���
            for i_i = 1:64
                if diff_block(i_i) ~= 0
                    if(diff_block(i_i) == 1)
                        block_cost_plus1(i_i) = cost_stego(i_i);
                    else
                        block_cost_minus1(i_i) = cost_stego(i_i);
                    end
                end
            end    
            cost_plus12(i:i+7,j:j+7) = cost_plus12(i:i+7,j:j+7)+ block_cost_plus1;
            cost_minus12(i:i+7,j:j+7) =cost_minus12(i:i+7,j:j+7) +  block_cost_minus1;
            %cost_plus12(i:i+7,j:j+7) = block_cost_plus1;
            %cost_minus12(i:i+7,j:j+7) = block_cost_minus1;
        end
    end
    sum_error(index) = total_cost;
    num_error(index) = (diff_num);
    if(sum_error(index) < minV)
        minV_index = index;
        minV = sum_error(index); 
    end
    if(index == 5)
        cost_plus1 = reshape(cost_plus1_array(minV_index,:,:),jpeg_size);
        cost_minus1 = reshape(cost_minus1_array(minV_index,:,:),jpeg_size);
        return;
    end
    index = index + 1;
    cost_plus1 = cost_plus12; %����cost_plus1
    cost_minus1 = cost_minus12;%����cost_minus1
end
end
        