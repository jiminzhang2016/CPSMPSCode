function [p,class] = dicidep85bossABSDDPR(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio)

pValues = [0.1294, 0.1741,  0.2114, 0.2480];

pValues2 = [0,0.5,0.5,1];
imgP = getmaxIndex65(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio);
diff = pValues - imgP;
[sorta,sortb] = sort(abs(diff));
p = pValues2(sortb(1));
class = sortb(1);
if payload == 0.1
     if p > 0.25
        p = 0.25;
    end
elseif payload==0.2
    if p > 0.5
        p = 0.5;
    end
elseif payload == 0.3
    if p < 0.5
        p = 0.5;
    end
else
    p = 1;
end
end