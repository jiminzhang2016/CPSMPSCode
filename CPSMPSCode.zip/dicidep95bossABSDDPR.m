function [p,class] = dicidep95bossABSDDPR(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio)

pValues = [0.1770, 0.2449, 0.3102, 0.707];

pValues2 = [0,0.5,1,1];
imgP = getmaxIndex65(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio);
diff = pValues - imgP;
[sorta,sortb] = sort(abs(diff));
p = pValues2(sortb(1));
class = sortb(1);
if payload == 0.1
    p = 0;
elseif payload==0.2
    if p < 0.5
        p = 0.5;
    end
elseif payload == 0.3
   p = 1;
else
    p = 1;
end
end