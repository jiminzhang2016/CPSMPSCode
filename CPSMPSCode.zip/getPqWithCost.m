function [rhoP1J, rhoM1J, e] = getPqWithCost(jpegName, pngName, rhoP1J, rhoM1J)
jpeg_str = jpeg_read(jpegName);
jpeg_quant = jpeg_str.quant_tables{1};
jpeg_coef = jpeg_str.coef_arrays{1};
img = double(imread(pngName));
[h, w] = size(img);
resultDCT = zeros([h, w]);

for i=1:8:h
    for j=1:8:w
        imgBlock = img(i:i+7,j:j+7)-128;
        imgDct = dct2(imgBlock);
        quantDct = imgDct ./ jpeg_quant;
        resultDCT(i:i+7,j:j+7) = quantDct;
      
    end
end


roundError = resultDCT - round(resultDCT);
for i=1:h
    for j=1:w
        if roundError(i, j) > 0
            rhoP1J(i, j) =  (1 - 2 * abs(roundError(i, j))) * rhoP1J(i, j);
        elseif roundError(i, j) < 0
            rhoM1J(i, j) =  (1 - 2 * abs(roundError(i, j))) * rhoM1J(i, j);
        end
    end
end
e = roundError;
end