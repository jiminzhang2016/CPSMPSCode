pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspcl8new\\stego.mat')

pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspcl8new\\stego.mat')


pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspcl8new\\stego.mat')

pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspcl8new\\stego.mat')

pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.1uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.1uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.1uerdspcl8new\\stego.mat')

pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.2uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.2uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.2uerdspcl8new\\stego.mat')


pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.3uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.3uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.3uerdspcl8new\\stego.mat')

pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.4uerdspcl8new\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.4uerdspcl8new\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.4uerdspcl8new\\stego.mat')

