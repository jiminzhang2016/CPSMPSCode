makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspc\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspc\stego.mat');
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspc\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspc\stego.mat');
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspc\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspc\stego.mat');
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspc\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspc\stego.mat');
pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspc\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspc\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspc\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspc\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);


makeFeature2(75, 'D:\imageSet\randomPgm2k75Magick\', 'D:\imageSet\randomPgm2k75Magick\cover.mat');
pathstego = 'D:\imageSet\randomPgm2k75Magick\';
my_GFR(pathstego, [pathstego,'\cover.mat'], 75);