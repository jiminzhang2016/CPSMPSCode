for i=1:10000
    fileName = ['D:\Code\Experiments\Ex752\test_all\stego05\',num2str(i),'.jpg'];
    if(exist(fileName)~=0)
        coverFileName = ['D:\Code\Experiments\Ex752\test_all\cover\', num2str(i), '.jpg'];
        dstName = ['D:\Code\Experiments\Ex752\test_all\cover05\', num2str(i),'.jpg'];
        copyfile(coverFileName, dstName);
    end
    fileName = ['D:\Code\Experiments\Ex752\test_all\stego10\',num2str(i),'.jpg'];
    if(exist(fileName)~=0)
        coverFileName = ['D:\Code\Experiments\Ex752\test_all\cover\', num2str(i), '.jpg'];
        dstName = ['D:\Code\Experiments\Ex752\test_all\cover10\', num2str(i),'.jpg'];
        copyfile(coverFileName, dstName);
    end
    fileName = ['D:\Code\Experiments\Ex752\test_all\stego20\',num2str(i),'.jpg'];
    if(exist(fileName)~=0)
        coverFileName = ['D:\Code\Experiments\Ex752\test_all\cover\', num2str(i), '.jpg'];
        dstName = ['D:\Code\Experiments\Ex752\test_all\cover20\', num2str(i),'.jpg'];
        copyfile(coverFileName, dstName);
    end
    fileName = ['D:\Code\Experiments\Ex752\test_all\stego30\',num2str(i),'.jpg'];
    if(exist(fileName)~=0)
        coverFileName = ['D:\Code\Experiments\Ex752\test_all\cover\', num2str(i), '.jpg'];
        dstName = ['D:\Code\Experiments\Ex752\test_all\cover30\', num2str(i),'.jpg'];
        copyfile(coverFileName, dstName);
    end
end