makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=0\0.1\', 'D:\Code\predict_net3\diffk\k=0\0.1\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=0\0.2\', 'D:\Code\predict_net3\diffk\k=0\0.2\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=0\0.3\', 'D:\Code\predict_net3\diffk\k=0\0.3\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=0\0.4\', 'D:\Code\predict_net3\diffk\k=0\0.4\stego.mat');

makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=5\0.1\', 'D:\Code\predict_net3\diffk\k=5\0.1\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=5\0.2\', 'D:\Code\predict_net3\diffk\k=5\0.2\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=5\0.3\', 'D:\Code\predict_net3\diffk\k=5\0.3\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=5\0.4\', 'D:\Code\predict_net3\diffk\k=5\0.4\stego.mat');

makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=10\0.1\', 'D:\Code\predict_net3\diffk\k=10\0.1\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=10\0.2\', 'D:\Code\predict_net3\diffk\k=10\0.2\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=10\0.3\', 'D:\Code\predict_net3\diffk\k=10\0.3\stego.mat');
makeFeature(1000, 85, 'D:\Code\predict_net3\diffk\k=10\0.4\', 'D:\Code\predict_net3\diffk\k=10\0.4\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\', 'D:\stegoPath\65fakeimage\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\beishu2NewPgm\', 'D:\stegoPath\65fakeimage\beishu2NewPgm\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\beishu3NewPgm\', 'D:\stegoPath\65fakeimage\beishu3NewPgm\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\beishu4NewPgm\', 'D:\stegoPath\65fakeimage\beishu4NewPgm\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\beishu4\', 'D:\stegoPath\65fakeimage\beishu4\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\beishu2\', 'D:\stegoPath\65fakeimage\beishu2\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\realhigh0.25\', 'D:\stegoPath\65fakeimage\realhigh0.25\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\reallow0.25\', 'D:\stegoPath\65fakeimage\reallow0.25\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\prehigh0.25\', 'D:\stegoPath\65fakeimage\prehigh0.25\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\prelow0.25\', 'D:\stegoPath\65fakeimage\prelow0.25\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\reallow0.25\', 'D:\stegoPath\65fakeimage\reallow0.25\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabove\0.1\', 'D:\stegoPath\65fakeimage\testembeddingabove\0.1\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabove\0.2\', 'D:\stegoPath\65fakeimage\testembeddingabove\0.2\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabove\0.3\', 'D:\stegoPath\65fakeimage\testembeddingabove\0.3\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabove\0.4\', 'D:\stegoPath\65fakeimage\testembeddingabove\0.4\stego.mat');


makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.1\', 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.1\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.2\', 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.2\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.3\', 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.3\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.4\', 'D:\stegoPath\65fakeimage\testembeddingabovereal\0.4\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddinglsb\0.1\', 'D:\stegoPath\65fakeimage\testembeddinglsb\0.1\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddinglsb\0.2\', 'D:\stegoPath\65fakeimage\testembeddinglsb\0.2\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddinglsb\0.3\', 'D:\stegoPath\65fakeimage\testembeddinglsb\0.3\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddinglsb\0.4\', 'D:\stegoPath\65fakeimage\testembeddinglsb\0.4\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testembeddinglsb\0\', 'D:\stegoPath\65fakeimage\testembeddinglsb\0\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\bow75\0.4\', 'D:\stegoPath\65fakeimage\bow75\0.4\stego.mat');
makeFeature(1000, 75, 'D:\imageSet\Bow75\', 'D:\imageSet\Bow75\cover.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\bow75\Li65\0.4\', 'D:\stegoPath\65fakeimage\bow75\Li65\0.4\stego.mat');


makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=1\0.1\', 'D:\stegoPath\65fakeimage\testp\p=1\0.1\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=1\0.2\', 'D:\stegoPath\65fakeimage\testp\p=1\0.2\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=1\0.3\', 'D:\stegoPath\65fakeimage\testp\p=1\0.3\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=1\0.4\', 'D:\stegoPath\65fakeimage\testp\p=1\0.4\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0.6\0.1\', 'D:\stegoPath\65fakeimage\testp\p=0.6\0.1\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0.6\0.2\', 'D:\stegoPath\65fakeimage\testp\p=0.6\0.2\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0.6\0.3\', 'D:\stegoPath\65fakeimage\testp\p=0.6\0.3\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0.6\0.4\', 'D:\stegoPath\65fakeimage\testp\p=0.6\0.4\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0\0.1\', 'D:\stegoPath\65fakeimage\testp\p=0\0.1\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0\0.2\', 'D:\stegoPath\65fakeimage\testp\p=0\0.2\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0\0.3\', 'D:\stegoPath\65fakeimage\testp\p=0\0.3\stego.mat');
makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0\0.4\', 'D:\stegoPath\65fakeimage\testp\p=0\0.4\stego.mat');

makeFeature(1000, 75, 'D:\stegoPath\65fakeimage\testp\p=0.6_N=40\0.2\', 'D:\stegoPath\65fakeimage\testp\p=0.6_N=40\0.2\stego.mat');