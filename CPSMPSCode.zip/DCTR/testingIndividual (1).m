function results = testingIndividual(testingImgMat, trainedMat)
testingStruct = load(testingImgMat);
testingFeature = testingStruct.F;
testingName = testingStruct.names;
model = load(trainedMat);
ensembles = model.trained_ensemble;
[results, coverRatio, stegoRatio] = ensemble_testing(testingFeature,ensembles);
ratio = stegoRatio ./ coverRatio;
all_number = 1;
number = 0;
srcDir = 'D:\Code\BatchExperiment\deeplearningcover3\pgm';
dstDir = 'D:\Code\BatchExperiment\selectCoverPart1';
for i=1:length(ratio)
    if ratio(i)<1
        name = testingName{i};
        all_number = ratio(i) * all_number;
        number = number + 1;
        srcPath = [srcDir, '\\', name];
        dstPath = [dstDir, '\\', name];
        copyfile(srcPath, dstPath);
    end
end
end