function embedding11295
addpath('D:\gitCode\DCTR\');
p=0;
N=40;
maxT = 8;
payload = 0.1;
t = 0.2;
parfor i=1:1000
    coverName = ['D:\imageSet\Bow75\',num2str(i),'.jpg'];
    pngName = ['D:\imageSet\predictedPngBow75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.1\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.1\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.1\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, payload, 1, i, p, 123456, pngName, N, maxT, t);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.1\', 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.1\stego.mat');
p=0.6;
N=20;
maxT = 4;
payload = 0.2;
t = 0.2;
parfor i=1:1000
    coverName = ['D:\imageSet\Bow75\',num2str(i),'.jpg'];
    pngName = ['D:\imageSet\predictedPngBow75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.2\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.2\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.2\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, payload, 1, i, p, 123456, pngName, N, maxT, t);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.2\', 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.2\stego.mat');
p=1;
N=40;
maxT = 4;
payload = 0.3;
t = 0.2;
parfor i=1:1000
    coverName = ['D:\imageSet\Bow75\',num2str(i),'.jpg'];
    pngName = ['D:\imageSet\predictedPngBow75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.3Newt=0.2\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.3Newt=0.2\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.3Newt=0.2\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, payload, 1, i, p, 123456, pngName, N, maxT, t);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.3Newt=0.2\', 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.3Newt=0.2\stego.mat');
tutorial('D:\imageSet\Bow75\cover.mat','D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.3Newt=0.2\\stego.mat')
p=1;
N=10;
maxT = 4;
payload = 0.4;
t = 0.2;
parfor i=1:1000
    coverName = ['D:\imageSet\Bow75\',num2str(i),'.jpg'];
    pngName = ['D:\imageSet\predictedPngBow75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.4\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.4\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.4\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, payload, 1, i, p, 123456, pngName, N, maxT, t);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.4\', 'D:\\stegoPath\65fakeimage\\testp\testComparison\Bow\75\0.4\stego.mat');
end