index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerd\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerd\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerd\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerd\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerd\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerd\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerd\stego\stego.mat', 95);

index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerd\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerd\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerd\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerd\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerd\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerd\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerd\stego\stego.mat', 95);

index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerd\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerd\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerd\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerd\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerd\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerd\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerd\stego\stego.mat', 95);

index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerd\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerd\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerd\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerd\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerd\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerd\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerd\stego\stego.mat', 95);

index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerdspc\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerdspc\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerdspc\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerdspc\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerdspc\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerdspc\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.1uerdspc\stego\stego.mat', 95);

index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerdspc\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerdspc\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerdspc\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerdspc\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerdspc\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerdspc\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.2uerdspc\stego\stego.mat', 95);

index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerdspc\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerdspc\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerdspc\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerdspc\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerdspc\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerdspc\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.3uerdspc\stego\stego.mat', 95);

index = 0;
for i=1:10000
    imgDstPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerdspc\cover'];
    if(exist(imgDstPath, 'dir') == 0)
        mkdir(imgDstPath);
    end
    stegoPath  = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerdspc\stego\',num2str(i),'.jpg'];
    if(exist(stegoPath, 'file')~=0)
        index = index + 1;
        imgDstPath = ['D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerdspc\cover\', num2str(i), '.jpg'];
        imgSrcPath = ['D:\imageSet\randomPgm2k95Magick\',num2str(i),'.jpg'];
        copyfile(imgSrcPath, imgDstPath);
    end
end
my_GFR( 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerdspc\cover\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerdspc\cover\cover.mat', 95);
my_GFR('D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerdspc\stego\', 'D:\Paper5\Bas\stegoPath\QF95MagickRandom0.4uerdspc\stego\stego.mat', 95);
