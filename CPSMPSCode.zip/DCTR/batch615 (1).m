makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake1\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake1\stego.mat');
makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake2\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake2\stego.mat');
makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake3\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake3\stego.mat');
makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake4\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake4\stego.mat');

makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake1\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake1\stego.mat');
makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake2\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake2\stego.mat');
makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake3\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake3\stego.mat');
makeFeature2(75, 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake4\', 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake4\stego.mat');


pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake1\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake2\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake3\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortPre\fake4\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);


pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake1\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake2\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake3\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake4\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);

pathstego = 'D:\CodeForPaper3\qf75\stegoPath\fakeImg\sortReal\fake0\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);