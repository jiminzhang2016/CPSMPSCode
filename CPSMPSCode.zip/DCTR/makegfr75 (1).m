pathstego = 'D:\CodeForPaper3\qf75\random2000Stego\JUNIWARD\0.1Li';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);

pathstego = 'D:\CodeForPaper3\qf75\stegoPath\lastsecondratio220p = 0maxT=4rho=1.5beta=1payload=0.1';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\random2000Stego\JUNIWARD\li_0.2';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\lastsecondratio220p = 0.5maxT=4rho=1.5beta=1payload=0.2';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\lastsecondratio220p = 0.75maxT=4rho=1.5beta=1payload=0.3';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\CodeForPaper3\qf75\stegoPath\lastsecondratio220p = 0.75maxT=4rho=1.5beta=1payload=0.4';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);


