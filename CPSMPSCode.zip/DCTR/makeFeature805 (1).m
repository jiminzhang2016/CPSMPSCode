function makeFeature805()
qf = 75;
fileNum = 872;
filePath = 'D:\Code\Experiments\Ex752\method3\cover\';
dstName = 'D:\Code\Experiments\Ex752\method3\cover.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex752\method3\stego05\';
dstName = 'D:\Code\Experiments\Ex752\method3\stego05.mat';
makeFeature(fileNum, qf, filePath, dstName);

filePath = 'D:\Code\Experiments\Ex752\method3\stego10\';
dstName = 'D:\Code\Experiments\Ex752\method3\stego10.mat';
makeFeature(fileNum, qf, filePath, dstName);

filePath = 'D:\Code\Experiments\Ex752\method3\stego20\';
dstName = 'D:\Code\Experiments\Ex752\method3\stego20.mat';
makeFeature(fileNum, qf, filePath, dstName);

filePath = 'D:\Code\Experiments\Ex752\method3\stego30\';
dstName = 'D:\Code\Experiments\Ex752\method3\stego30.mat';
makeFeature(fileNum, qf, filePath, dstName);


end