function newBatch2()
my_GFR('D:\Code\Experiments\A2\new_test_all\stego050\', 'D:\Code\Experiments\A2\new_test_all\stego05dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\new_test_all\stego100\', 'D:\Code\Experiments\A2\new_test_all\stego10dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\new_test_all\stego200\', 'D:\Code\Experiments\A2\new_test_all\stego20dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\new_test_all\stego300\', 'D:\Code\Experiments\A2\new_test_all\stego30dctr.matt', 85);
my_GFR('D:\Code\Experiments\A2\new_test_all\cover\', 'D:\Code\Experiments\A2\new_test_all\cover.mat', 85);

my_GFR('D:\Code\Experiments\A2\method2\0\stego_050\', 'D:\Code\Experiments\A2\method2\0\stego05dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method2\0\stego_100\', 'D:\Code\Experiments\A2\method2\0\stego10dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method2\0\stego_200\', 'D:\Code\Experiments\A2\method2\0\stego20dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method2\0\stego_300\', 'D:\Code\Experiments\A2\method2\0\stego30dctr.matt', 85);
my_GFR('D:\Code\Experiments\A2\method2\0\cover\', 'D:\Code\Experiments\A2\method2\0\cover.mat', 85);


my_GFR('D:\Code\Experiments\A2\method2\others\stego05\', 'D:\Code\Experiments\A2\method2\others\stego05dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method2\others\stego10\', 'D:\Code\Experiments\A2\method2\others\stego10dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method2\others\stego20\', 'D:\Code\Experiments\A2\method2\others\stego20dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method2\others\stego30\', 'D:\Code\Experiments\A2\method2\others\stego30dctr.matt', 85);
my_GFR('D:\Code\Experiments\A2\method2\others\cover\', 'D:\Code\Experiments\A2\method2\others\cover.mat', 85);

my_GFR('D:\Code\Experiments\A2\method3\stego005\', 'D:\Code\Experiments\A2\method3\stego05dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method3\stego010\', 'D:\Code\Experiments\A2\method3\stego10dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method3\stego020\', 'D:\Code\Experiments\A2\method3\stego20dctr.mat', 85);
my_GFR('D:\Code\Experiments\A2\method3\stego030\', 'D:\Code\Experiments\A2\method3\stego30dctr.matt', 85);
my_GFR('D:\Code\Experiments\A2\method3\cover\', 'D:\Code\Experiments\A2\method3\cover.mat', 85);

my_GFR('D:\Code\Experiments\GMAS\stego005\', 'D:\Code\Experiments\GMAS\stego05dctr.mat', 85);
my_GFR('D:\Code\Experiments\GMAS\stego010\', 'D:\Code\Experiments\GMAS\stego10dctr.mat', 85);
my_GFR('D:\Code\Experiments\GMAS\stego020\', 'D:\Code\Experiments\GMAS\stego20dctr.mat', 85);
my_GFR('D:\Code\Experiments\GMAS\stego030\', 'D:\Code\Experiments\GMAS\stego30dctr.matt', 85);

end