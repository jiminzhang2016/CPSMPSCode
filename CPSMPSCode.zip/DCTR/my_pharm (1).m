function my_pharm(image_path, feature_path, QF)
addpath(fullfile('..\JPEGTool'));
QF = uint32(QF);
NR = 32; 
files = dir([image_path '/*.jpg']);
file_num = length(files);
F = single( zeros(file_num,12600) );
names = cell(file_num,1);

parfor w = 1:length(files)
    tic
    jpegfilename = [image_path '/' files(w).name];
    ImageSet = jpegfilename; 
    f = makePharmFeature(ImageSet, QF);
    F(w,:) = f(:);
    %names{w} = [num2str(w) '.jpg'];
	names{w} = files(w).name;
    toc
end
save(feature_path,'F','names');
