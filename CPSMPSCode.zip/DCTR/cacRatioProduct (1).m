function results = cacRatioProduct(testingImgMat, trainedMat)
testingStruct = load(testingImgMat);
testingFeature = testingStruct.F;
model = load(trainedMat);
ensembles = model.trained_ensemble;
[results, coverRatio, stegoRatio] = ensemble_testing(testingFeature,ensembles);
ratio = stegoRatio ./ coverRatio;
all_number = 1;
for i=1:length(ratio)
   all_number = ratio(i) * all_number;
end
end

