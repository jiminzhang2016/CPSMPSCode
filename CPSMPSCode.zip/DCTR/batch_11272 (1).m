function batch_11272
addpath('D:\gitCode\DCTR\');
result = [1000, 6];
p=0;
N=10;
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=0_N=10\0.1\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=0_N=10\0.1\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=0_N=10\0.1\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.1, 1, i, p, 123456, pngName, 10, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=0_N=10\0.1\', 'D:\\stegoPath\65fakeimage\\testp\p=0_N=10\0.1\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=0_N=20\0.1\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=0_N=20\0.1\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=0_N=20\0.1\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.1, 1, i, p, 123456, pngName, 20, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=0_N=20\0.1\', 'D:\\stegoPath\65fakeimage\\testp\p=0_N=20\0.1\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=0_N=40\0.1\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=0_N=40\0.1\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=0_N=40\0.1\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.1, 1, i, p, 123456, pngName, 40, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=0_N=40\0.1\', 'D:\\stegoPath\65fakeimage\\testp\p=0_N=40\0.1\stego.mat');
p=0.6;
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=0.6_N=10\0.2\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=0.6_N=10\0.2\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=0.6_N=10\0.2\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.2, 1, i, p, 123456, pngName, 10, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=0.6_N=10\0.1\', 'D:\\stegoPath\65fakeimage\\testp\p=0.6_N=10\0.2\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=0.6_N=20\0.2\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=0.6_N=20\0.2\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=0.6_N=20\0.2\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.2, 1, i, p, 123456, pngName, 20, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=0.6_N=20\0.1\', 'D:\\stegoPath\65fakeimage\\testp\p=0.6_N=20\0.2\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=0.6_N=40\0.2\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=0.6_N=40\0.2\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=0.6_N=40\0.2\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.2, 1, i, p, 123456, pngName, 40, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=0.6_N=40\0.1\', 'D:\\stegoPath\65fakeimage\\testp\p=0.6_N=40\0.2\stego.mat');
p=1;
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.3\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.3\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.3\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.3, 1, i, p, 123456, pngName, 10, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.3\', 'D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.3\\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.3\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.3\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.3\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.3, 1, i, p, 123456, pngName, 20, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.3\', 'D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.3\\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.3\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.3\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.3\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.3, 1, i, p, 123456, pngName, 40, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.3\', 'D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.3\\stego.mat');

parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.4\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.4\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.4\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.4, 1, i, p, 123456, pngName, 10, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.4\', 'D:\\stegoPath\65fakeimage\\testp\p=1_N=10\0.4\\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.4\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.4\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.4\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.4, 1, i, p, 123456, pngName, 20, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.4\', 'D:\\stegoPath\65fakeimage\\testp\p=1_N=20\0.4\\stego.mat');
parfor i=9001:10000
    coverName = ['D:\gitCode\boss75\',num2str(i),'.jpg'];
    pngName = ['D:\gitCode\predictPNG75\'];
    stegoName = ['D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.4\', num2str(i),'.jpg'];
    if(exist(coverName, 'file')>0 )
        if(exist('D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.4\', 'dir')==0)
            mkdir('D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.4\');
        end
        %makeFakeImg(coverName, stegoName, 0.4, 1,i,pa, 12345, pngName, 4, 0, 'D:\spatial\spatial\');
        %embeddingWithPredictNoLogN2Distribution(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax)
       
         [resultAll, result1, result2, result3, result4, result5]   = embeddingWithPredictNoLogN2DistributionWithT(coverName, stegoName, 0.4, 1, i, p, 123456, pngName, 40, 4, 0.2);
    end
end
makeFeature(1000, 75, 'D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.4\', 'D:\\stegoPath\65fakeimage\\testp\p=1_N=40\0.4\\stego.mat');
end