function makeFeature711()
fileNum = 872;
qf = 75;
filePath = 'D:\Code\Experiments\Ex75\cover\';
dstName = 'D:\Code\Experiments\Ex75\feature_cover\cover.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\test_all\cover\';
dstName = 'D:\Code\Experiments\Ex75\test_all\cover.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\test_all\stego05\';
dstName = 'D:\Code\Experiments\Ex75\test_all\stego05.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\test_all\stego10\';
dstName = 'D:\Code\Experiments\Ex75\test_all\stego10.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\test_all\stego20\';
dstName = 'D:\Code\Experiments\Ex75\test_all\stego20.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\test_all\stego30\';
dstName = 'D:\Code\Experiments\Ex75\test_all\stego30.mat';
makeFeature(fileNum, qf, filePath, dstName);

filePath = 'D:\Code\Experiments\Ex75\method2\0\stego05\';
dstName = 'D:\Code\Experiments\Ex75\method2\0\\stego05.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method2\0\stego10\';
dstName = 'D:\Code\Experiments\Ex75\method2\0\stego10.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method2\0\stego20\';
dstName = 'D:\Code\Experiments\Ex75\method2\0\stego20.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method2\0\stego30\';
dstName = 'D:\Code\Experiments\Ex75\method2\0\stego30.mat';
makeFeature(fileNum, qf, filePath, dstName);

filePath = 'D:\Code\Experiments\Ex75\method2\others\cover\';
dstName = 'D:\Code\Experiments\Ex75\method2\others\cover.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method2\others\stego05\';
dstName = 'D:\Code\Experiments\Ex75\method2\others\stego05.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method2\others\stego10\';
dstName = 'D:\Code\Experiments\Ex75\method2\others\stego10.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method2\others\stego20\';
dstName = 'D:\Code\Experiments\Ex75\method2\others\stego20.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method2\others\stego30\';
dstName = 'D:\Code\Experiments\Ex75\method2\others\stego30.mat';
makeFeature(fileNum, qf, filePath, dstName);

filePath = 'D:\Code\Experiments\Ex75\method3\cover';
dstName = 'D:\Code\Experiments\Ex75\method3\cover.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method3\stego05\';
dstName = 'D:\Code\Experiments\Ex75\method3\stego05.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method3\stego10\';
dstName = 'D:\Code\Experiments\Ex75\method3\stego10.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method3\stego20\';
dstName = 'D:\Code\Experiments\Ex75\method3\stego20.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\method3\stego30\';
dstName = 'D:\Code\Experiments\Ex75\method3\stego30.mat';
makeFeature(fileNum, qf, filePath, dstName);



fileNum = 872;
qf = 75;
filePath = 'D:\Code\Experiments\Ex75\GMAS\0.05\';
dstName = 'D:\Code\Experiments\Ex75\GMAS\stego05.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\GMAS\0.10\';
dstName = 'D:\Code\Experiments\Ex75\GMAS\stego10.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\GMAS\0.20\';
dstName = 'D:\Code\Experiments\Ex75\GMAS\stego20.mat';
makeFeature(fileNum, qf, filePath, dstName);
filePath = 'D:\Code\Experiments\Ex75\GMAS\0.30\';
dstName = 'D:\Code\Experiments\Ex75\GMAS\stego30.mat';
makeFeature(fileNum, qf, filePath, dstName);


end