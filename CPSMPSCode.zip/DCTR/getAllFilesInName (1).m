%get the file name in a dir without path
function fileList = getAllFilesInName(dirName)

  dirData = dir(dirName);      %# Get the data for the current directory
  dirIndex = [dirData.isdir];  %# Find the index for directories
  fileList = {dirData(~dirIndex).name}';  %'# Get a list of the files
  if ~isempty(fileList)
    fileList = cellfun(@(x) fullfile(x),...  %# Prepend path to files
                       fileList,'UniformOutput',false);
  end

end
