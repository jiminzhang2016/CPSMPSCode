function makeCoverFolder()
for i=1:10000
    imgPath = ['D:\codeForSPCPaper\imageset911\Stegospc1024q953norandm\0.4\', num2str(i),'.jpg'];
    if(exist(imgPath,'file')~=0)
        dstPath = ['D:\codeForSPCPaper\imageset911\Stegospc1024q953norandm\cover\',num2str(i),'.jpg'];
        oldPath = ['D:\codeForSPCPaper\covermajack1024q95\covermajack1024q95\',num2str(i),'.jpg'];
        copyfile(oldPath,dstPath);
    end
end

for i=1:10000
    imgPath = ['D:\codeForSPCPaper\imageset911\Stegostc1024q953noranm\0.4\', num2str(i),'.jpg'];
    if(exist(imgPath,'file')~=0)
        dstPath = ['D:\codeForSPCPaper\imageset911\Stegostc1024q953noranm\cover\',num2str(i),'.jpg'];
        oldPath = ['D:\codeForSPCPaper\covermajack1024q95\covermajack1024q95\',num2str(i),'.jpg'];
        copyfile(oldPath,dstPath);
    end
end

end