index = 1;
result_array = results.votes;
filePath = 'D:\Code\ZhibiaoYanZheng\security\testing\newcover\';
for i=1:200
    fileName = names{i};
    file = [filePath, fileName];
    result_temp = result_array(i);
    if (result_temp < 0)
        delete(file);
        index = index + 1;
        if(index==100)
            break;
        end
    end
end