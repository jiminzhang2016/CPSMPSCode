load('G:\images\Image\cover.mat');

for i=1:2000
    names1{i} = newName{i};
    features1{i} = newF(i,:);
end
for i=2001:4000
    names2{i} = newName{i};
    features2{i} = newF(i,:);
end
newF = names1;
newName = features1;
save('G:\images\Image\testForResult\test1\cover.mat','newF','newName');
newF = features2;
newName = names2;
save('G:\images\Image\testForResult\test2\cover.mat','newF','newName');

load('G:\images\Image\stego.mat');
for i=1:2000
    names1{i} = newName{i};
    features1{i} = newF(i,:);
end
for i=2001:4000
    names2{i} = newName{i};
    features2{i} = newF(i,:);
end
newF = names1;
newName = features1;
save('G:\images\Image\testForResult\test1\stego.mat','newF','newName');
newF = features2;
newName = names2;
save('G:\images\Image\testForResult\test2\stego.mat','newF','newName');
