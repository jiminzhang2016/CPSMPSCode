function result = calculateResult(m1, m2)
result = (1-m1)*(1-m2);
end