function results = testingAllTests(testingImgMatCover, testingImgMatStego, trainedMat)
testingStruct = load(testingImgMatCover);
testingFeatureCover = testingStruct.newF;
testingNameCover = testingStruct.newName;
testingStruct = load(testingImgMatStego);
testingFeatureStego = testingStruct.newF;
testingNameStego = testingStruct.newName;
labelCover = zeros(length(testingFeatureCover(:,1)),1);
labelStego = ones(length(testingFeatureStego(:,1)),1);
labels = [labelCover;labelStego];
model = load(trainedMat);
ensembles = model.trained_ensemble;
testingFeature = [testingFeatureCover;testingFeatureStego];
[results, coverRatio1, stegoRatio1] = ensemble_testing(testingFeature,ensembles);
[value, pos] = sort(stegoRatio1);
testLabel = zeros(length(testingFeature(:,1)),1);
for i=length(testingFeature(:,1)) - 1* length(testingFeatureStego(:,1)):length(testingFeature(:,1))
    testLabel(pos(i)) = 1;
end
ratio = nnz(testLabel == labels) / length(testingFeature(:,1));

end