clc; clear all;
addpath(fullfile('D:\Code\Experiments\matlab\matlab\JPEGTool'));
% Specify all images for extraction
filepath_cover = strcat('E:\code\Robust_Steganography-master\GMAS\GMAS\stego0.2Random\');
imagenum=999; Dim=8000;
Feature_cover=single(zeros(imagenum,Dim));
names = cell(imagenum,1);
imgList = getAllFilesInName(filepath_cover);
quality_factor = 85;
for i=1:length(imgList)
    imfilecover = strcat(filepath_cover,imgList{i});  
    I_STRUCT = jpeg_read(imfilecover);
    F = DCTR(I_STRUCT, quality_factor);
    Feature_cover(i,:) = F; 
    name = imgList{i};
    names(i,1) = cellstr(name); %%����ת��char----> cell
    disp(strcat('current percentage:',num2str(i),'/',num2str(imagenum),',',imfilecover)); 
end
F = Feature_cover;
save(['E:\code\Robust_Steganography-master\GMAS\GMAS\features\', strcat('stego','.mat')],'names','F');    