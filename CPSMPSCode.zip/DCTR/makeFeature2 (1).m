function makeFeature2(qf, filePath, dstName)
addpath(fullfile('..\JPEGTool'));
% Specify all images for extraction
QF = double(qf);
NR = 32; 
files = dir([filePath '\*.jpg']);
file_num = length(files);
F = single( zeros(file_num,8000) );
names = cell(file_num,1);

parfor w = 1:length(files)
    tic
    jpegfilename = [filePath '\' files(w).name];
    ImageSet = jpegfilename; 
    jpeg_str = jpeg_read(ImageSet);
    f = DCTR(jpeg_str,  QF); 
    F(w,:) = f(:);
    %names{w} = [num2str(w) '.jpg'];
	names{w} = files(w).name;
    toc
end
save(dstName,'F','names');  
end