function result = makePharmFeature(fileName, qf)
I = jpeg_read(fileName);
F = PHARM_matlab(I, double(qf));
Ss = fieldnames(F);
fprintf('\n"F" contains %d submodel feature matrices (number of images x feature dimension): \n', numel(Ss));
startIndex = 1;
for Sid = 1:length(Ss)
    Fsingle = eval(['F.' Ss{Sid}]);
    size1 = size(Fsingle, 1) *  size(Fsingle, 2);
    result(startIndex:startIndex+size1-1) = Fsingle;
    startIndex = startIndex + size1;
end
end