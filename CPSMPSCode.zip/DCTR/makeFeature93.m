pathstego = 'D:\codeForSPCPaper\imageset911\Stegostc1024q953noranm\0.4\';
qf = 95;
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], qf);
makeFeature2(qf, pathstego, [pathstego,'\dctrstego.mat']);
%my_pharm( pathstego, [pathstego,'\pharmstego.mat'], qf);

pathstego = 'D:\codeForSPCPaper\imageset911\Stegostc1024q953noranm\cover\';
qf = 95;
my_GFR(pathstego, [pathstego,'\gfrcover.mat'], qf);
makeFeature2(qf, pathstego, [pathstego,'\dctrcover.mat']);
%my_pharm( pathstego, [pathstego,'\pharmstego.mat'], qf);

pathstego = 'D:\codeForSPCPaper\imageset911\Stegospc1024q953norandm\0.4\';
qf = 95;
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], qf);
makeFeature2(qf, pathstego, [pathstego,'\dctrstego.mat']);
%my_pharm( pathstego, [pathstego,'\pharmstego.mat'], qf);

pathstego = 'D:\codeForSPCPaper\imageset911\Stegospc1024q953norandm\cover\';
qf = 95;
my_GFR(pathstego, [pathstego,'\gfrcover.mat'], qf);
makeFeature2(qf, pathstego, [pathstego,'\dctrcover.mat']);
%my_pharm( pathstego, [pathstego,'\pharmstego.mat'], qf);
