my_pharm( 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0maxT=4rho=1.5beta=1payload=0.1\', 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0maxT=4rho=1.5beta=1payload=0.1\pharmstego.mat', 75);
my_pharm( 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0.5maxT=4rho=1.5beta=1payload=0.2\', 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0.5maxT=4rho=1.5beta=1payload=0.2\pharmstego.mat', 75);
my_pharm( 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0.75maxT=4rho=1.5beta=1payload=0.3\', 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0.75maxT=4rho=1.5beta=1payload=0.3\pharmstego.mat', 75);
my_pharm( 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0.75maxT=4rho=1.5beta=1payload=0.4\', 'D:\imageSet\BOWStego\75oldprealDNlastsecondratio2N=20p = 0.75maxT=4rho=1.5beta=1payload=0.4\pharmstego.mat', 75);

my_pharm( 'D:\imageSet\BOWStego\75realDNlastsecondratio2N=20p = varied2maxT=4rho=1.5beta=1payload=0.1\', 'D:\imageSet\BOWStego\75realDNlastsecondratio2N=20p = varied2maxT=4rho=1.5beta=1payload=0.1\pharmstego.mat', 75);

