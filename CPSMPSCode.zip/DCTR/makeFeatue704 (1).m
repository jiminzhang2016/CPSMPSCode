makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspcl8\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspcl8\stego.mat');
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspcl8\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspcl8\\stego.mat');
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspcl8\\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspcl8\\stego.mat');
makeFeature2(75, 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspcl8\\', 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspcl8\\stego.mat');

makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.1uerdspcl8\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.1uerdspcl8\stego.mat');
makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.2uerdspcl8\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.2uerdspcl8\\stego.mat');
makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.3uerdspcl8\\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.3uerdspcl8\\stego.mat');
makeFeature2(85, 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.4uerdspcl8\\', 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.4uerdspcl8\\stego.mat')


pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.1uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.2uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.3uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);
pathstego = 'D:\Paper5\Bas\stegoPath\QF75MagickRandom0.4uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 75);

pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.1uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.2uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.3uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
pathstego = 'D:\Paper5\Bas\stegoPath\QF85MagickRandom0.4uerdspcl8\';
my_GFR(pathstego, [pathstego,'\gfrstego.mat'], 85);
