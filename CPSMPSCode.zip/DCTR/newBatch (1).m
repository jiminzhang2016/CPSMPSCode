function newBatch()
my_GFR('D:\Code\Experiments\Ex902\method1\stego05\', 'D:\Code\Experiments\Ex902\method1\stego05gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method1\stego10\', 'D:\Code\Experiments\Ex902\method1\stego10gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method1\stego20\', 'D:\Code\Experiments\Ex902\method1\stego20gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method1\stego30\', 'D:\Code\Experiments\Ex902\method1\stego30gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method1\cover\', 'D:\Code\Experiments\Ex902\method1\covergfrr.mat', 90);

my_GFR('D:\Code\Experiments\Ex902\method2\0\stego05\', 'D:\Code\Experiments\Ex902\method2\0\stego05gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\0\stego10\', 'D:\Code\Experiments\Ex902\method2\0\stego10gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\0\stego20\', 'D:\Code\Experiments\Ex902\method2\0\stego20gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\0\stego30\', 'D:\Code\Experiments\Ex902\method2\0\stego30gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\0\cover\', 'D:\Code\Experiments\Ex902\method2\0\covergfrr.mat', 90);


my_GFR('D:\Code\Experiments\Ex902\method2\others\stego05\', 'D:\Code\Experiments\Ex902\method2\others\stego05gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\others\stego10\', 'D:\Code\Experiments\Ex902\method2\others\stego10gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\others\stego20\', 'D:\Code\Experiments\Ex902\method2\others\stego20gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\others\stego30\', 'D:\Code\Experiments\Ex902\method2\others\stego30gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method2\others\cover\', 'D:\Code\Experiments\Ex902\method2\others\covergfrr.mat', 90);


my_GFR('D:\Code\Experiments\Ex902\method3\stego05\', 'D:\Code\Experiments\Ex902\method3\stego05gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method3\stego10\', 'D:\Code\Experiments\Ex902\method3\stego10gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method3\stego20\', 'D:\Code\Experiments\Ex902\method3\stego20gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method3\stego30\', 'D:\Code\Experiments\Ex902\method3\stego30gfr.mat', 90);
my_GFR('D:\Code\Experiments\Ex902\method3\cover\', 'D:\Code\Experiments\Ex902\method3\covergfrr.mat', 90);


my_GFR('D:\Code\Experiments\Ex90nouse\GMAS\0.05\', 'D:\Code\Experiments\Ex90nouse\GMAS\stego05dctr.mat', 90);
my_GFR('D:\Code\Experiments\Ex90nouse\GMAS\0.1\', 'D:\Code\Experiments\Ex90nouse\GMAS\stego10dctr.mat', 90);
my_GFR('D:\Code\Experiments\Ex90nouse\GMAS\0.2\', 'D:\Code\Experiments\Ex90nouse\GMAS\stego20dctr.mat', 90);
my_GFR('D:\Code\Experiments\Ex90nouse\GMAS\0.3\', 'D:\Code\Experiments\Ex90nouse\GMAS\stego30dctr.mat', 90);
end