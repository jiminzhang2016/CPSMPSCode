function makeFeature(fileNum, qf, filePath, dstName)
addpath(fullfile('..\JPEGTool'));
% Specify all images for extraction
filepath_stego = strcat(filePath);
imagenum=fileNum; Dim=8000;
Feature_Stego=single(zeros(imagenum,Dim));
names = cell(imagenum,1);
imgList = getAllFilesInName(filepath_stego);
quality_factor = qf;
parfor i=1:length(imgList)
    imfileStego = strcat(filepath_stego,imgList{i});
    I_STRUCT = jpeg_read(imfileStego);
    F = DCTR(I_STRUCT, quality_factor);
    Feature_Stego(i,:) = F; 
    name = imgList{i};
    names(i,1) = cellstr(name); %%ÀàÐÍ×ª»»char----> cell
    %disp(strcat('current percentage:',num2str(i),'/',num2str(imagenum),',',imfileStego)); 
end
F = Feature_Stego;
save(dstName, 'names','F');    
end