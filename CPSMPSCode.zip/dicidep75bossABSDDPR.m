function [p,class] = dicidep75bossABSDDPR(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio)

pValues = [0.1137, 0.1542, 0.1863, 0.2165, 0.2426];
pValues2 = [0,0.5,0.75,0.75,0.75];
imgP = getmaxIndex65(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio);
diff = pValues - imgP;
[sorta,sortb] = sort(abs(diff));
p = pValues2(sortb(1));
class = sortb(1);
if payload == 0.1
    p = 0;
elseif payload==0.2
    if p > 0.5
        p = 0.5;
    end
elseif payload == 0.3
    if p > 0.75
        p = 0.75;
    end
else
    p = 0.75;
end
end