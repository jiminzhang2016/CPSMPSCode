function [output_result,output_real,output_result2] = getPreDirectionSSRQCPngNum(fileName,fileNameNum, pngPath)
addpath('JPEGTool');
pngName = [pngPath,num2str(fileNameNum),'.png'];
img = imread(pngName);
jpegStru = jpeg_read(fileName);
jpegDct = jpegStru.coef_arrays{1};
coef1 = jpegStru.quant_tables{1};
sizes = size(jpegDct);
output_result = zeros(sizes);
output_real = zeros(sizes);
for i=1:8:sizes(1)
    for j=1:8:sizes(2)
        spatial_block = double(img(i:i+7,j:j+7)) - 128;
        dct_pre = dct2(spatial_block) ./ coef1;
        old_dct =  jpegDct(i:i+7,j:j+7);
        dct_result = dct_pre;
        diff = dct_pre - old_dct;
        for ii=1:8
            for jj=1:8
                if diff(ii,jj) > 0 
                    result_part(ii,jj) = 1;
                elseif(diff(ii,jj)<0)
                    result_part(ii,jj) = -1;
                else
                    result_part(ii,jj) = 0;
                end
            end
        end
        diff2 = dct_pre - round(dct_pre);
        for ii=1:8
            for jj=1:8
                if diff2(ii,jj) > 0 
                    result_part2(ii,jj) = 1;
                elseif(diff2(ii,jj)<0)
                    result_part2(ii,jj) = -1;
                else
                    result_part2(ii,jj) = 0;
                end
            end
        end
        output_result2(i:i+7,j:j+7) = result_part2;
        output_result(i:i+7,j:j+7) = result_part;
        output_real(i:i+7,j:j+7) = dct_result;
    end
end
end