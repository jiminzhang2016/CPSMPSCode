function maxIndex65 = getmaxIndex65(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio)
addpath('cost','JPEGTool','STCTool');
oldFileName = fileName;
oldNum = num;
fileName = oldFileName;
num = oldNum;
folderNum = n;
jpeg_struct = jpeg_read(fileName);
jpeg_dct = jpeg_struct.coef_arrays{1};

dct_ratio = nnz(jpeg_dct) / length(jpeg_dct(:));
base_factor = 10;
%base_factor = 1;
[rhoP1, rhoM1] = J_UNIWARD(fileName);
sizeImg = size(rhoP1);
lenImg = sizeImg(1) * sizeImg(2);
reshaped = reshape(rhoP1, [lenImg, 1]); %for positioning
[sorted, sortedIndex] = sort(reshaped);
%[preDirection, pr] = getPreDirection(fileName,seed);
[preDirection, pr] = getPreDirectionSSRQCPngNum(fileName,num, pngName);
%[rhop1Real, rhom1Real] = getPq(fileName, pngName);
[rhop1Real, rhom1Real] = getPqWithCost(fileName, [pngName,num2str(num),'.png'],rhoP1, rhoM1 );
reshapedSP1 = reshape(rhop1Real,[lenImg,1]);
reshapedSM1 = reshape(rhom1Real, [lenImg, 1]);
reshapedMix = reshape([rhop1Real,rhom1Real], [lenImg * 2, 1]);
[sortedSP1, ~] = sort(reshapedSP1);
[sortedSM1, sortedIndexSM1] = sort(reshapedSM1);
[sortedMix, sortedIndexMix] = sort(reshapedMix);
m  = payload * (nnz(jpeg_dct) - nnz(jpeg_dct(1:8:sizeImg(1),1:8:sizeImg(2))));
%[y, p1Pq, m1Pq] =  EmbeddingSimulator(jpeg_dct, rhop1Real, rhom1Real, m);
%distortionReal = sum(sum(p1Pq.*rhop1Real) + sum(m1Pq .* rhom1Real));
%[y, p1O, m1O] =  EmbeddingSimulator(jpeg_dct, rhoP1, rhoM1, m);
%distortionO = sum(sum(p1O.*rhop1Real) + sum(m1O .* rhom1Real));
diff_round = pr - round(pr);
rhoP1Copy = rhoP1;
rhoM1Copy = rhoM1;
rightNum = 0;
allNum = 0;
b = 1;
lenChange = round(lenImg * b);
a = 0.65;
c = 0;
rhoP1 = rhoP1Copy;
rhoM1 = rhoM1Copy;
rightNum = 0;
allNum = 0;
if(usePredict)
    for i=1:lenChange
        index = sortedIndex(i);
        if( abs(diff_round(index)) > c)
            allNum = allNum + 1;
            if preDirection(index)>0  
                if(rhop1Real(index) < rhom1Real(index))
                    rightNum = rightNum + 1;
                end
                rhoP1(index) = rhoP1(index) * a;
            elseif preDirection(index)<0
                if(rhop1Real(index) > rhom1Real(index))
                    rightNum = rightNum + 1;
                end
                rhoM1(index) = rhoM1(index) * a;
            end
        end
    end
end
rng(randkey);
randPerm = randperm(lenImg);
jpeg_y_perm = int32(jpeg_dct(randPerm));
jpegdct_row = jpeg_dct(1:length(randPerm));
rhoP165 = rhoP1;
rhoM165 = rhoM1;
rhoP1_perm = rhoP1(randPerm);
rhoM1_perm = rhoM1(randPerm);
%rhoP1_perm = rhoP1Copy(randPerm);
%rhoM1_perm = rhoM1Copy(randPerm);
rho = zeros(3,lenImg,'single');
rho(1,:) = rhoM1_perm;
rho(3,:) = rhoP1_perm;
nzac = uint32(payload * (nnz(jpeg_dct) - nnz(jpeg_dct(1:8:sizeImg(1),1:8:sizeImg(2)))));
rng(randkey);
msg_embeded = uint8(round(rand([1, nzac])));
for times = 1:10
     try
        [D stego, n_msg_bits l] = stc_pm1_pls_embed(jpeg_y_perm, rho, msg_embeded, 7);
        break;
     catch
         if times == 10
             throw("error");
         end
         continue;
     end
end
    
for i=1:lenImg
            stego_real(randPerm(i)) = stego(i);
end
stego_real2 = reshape(stego_real, sizeImg);
jpeg_struct.coef_arrays{1} = double(stego_real2);
jpeg65DCT = double(stego_real2);
%jpeg_write(jpeg_struct, stegoName);
num = nnz(double(stego_real2) - jpeg_dct);
diff = double(stego_real2) - jpeg_dct;
diff = reshape(diff, [length(diff(:)),1]);
positionMix = zeros([length(diff)*2,1]);
maxIndex = 0;
indexArr = [];
indexArrIndex = 1;
for i = 1:length(diff)*2
    index = sortedIndexMix(i); 
    if(index>length(diff))
        index2 = index - length(diff);
        if(diff(index2) == -1)
           positionMix(i) = 1;
           indexArr(indexArrIndex) = i;
           indexArrIndex =  indexArrIndex + 1;
           maxIndex = i;
        end
    else
        if(diff(index) == 1)
           positionMix(i) = 1; %the real modification point in side domain
           indexArr(indexArrIndex) = i;
           indexArrIndex =  indexArrIndex + 1;
           maxIndex = i;
        end
    end
end
maxIndex65 = maxIndex/(length(diff)*2);

end