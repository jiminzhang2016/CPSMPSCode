function [p,class] = dicidep75boss(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio)

pValues = [0.1137, 0.1542, 0.1863, 0.2165, 0.2426];
pValues2 = [0,0.5,0.75,0.75,0.75];
imgP = getmaxIndex65(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio);
diff = pValues - imgP;
[sorta,sortb] = sort(abs(diff));
p = pValues2(sortb(1));
class = sortb(1);
end