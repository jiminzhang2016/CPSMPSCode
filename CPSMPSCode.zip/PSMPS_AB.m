function [resultAll, result1, result2, result3, result4, result7] = PSMPS_AB(fileName, stegoName, payload, usePredict,num,pa, randkey, pngName, n,theMax, t_max, base, beta, seed, record, newratio)
fid = fopen(record, 'a');
addpath('cost','JPEGTool','STCTool');
oldFileName = fileName;
oldNum = num;
fileName = oldFileName;
num = oldNum;
folderNum = n;
jpeg_struct = jpeg_read(fileName);
jpeg_dct = jpeg_struct.coef_arrays{1};

dct_ratio = nnz(jpeg_dct) / length(jpeg_dct(:));
base_factor = 10;
%base_factor = 1;
[rhoP1, rhoM1] = J_UNIWARD(fileName);
[sortedA,sortp] = sort(rhoP1);
sizeImg = size(rhoP1);
lenImg = sizeImg(1) * sizeImg(2);
reshaped = reshape(rhoP1, [lenImg, 1]); %for positioning
[sorted, sortedIndex] = sort(reshaped);
%[preDirection, pr] = getPreDirection(fileName,seed);
[preDirection, pr] = getPreDirectionSSRQCPngNum(fileName,num, pngName);
%[rhop1Real, rhom1Real] = getPq(fileName, pngName);
[rhop1Real, rhom1Real] = getPqWithCost(fileName, [pngName,num2str(num),'.png'],rhoP1, rhoM1 );
reshapedSP1 = reshape(rhop1Real,[lenImg,1]);
reshapedSM1 = reshape(rhom1Real, [lenImg, 1]);
reshapedMix = reshape([rhop1Real,rhom1Real], [lenImg * 2, 1]);
[sortedSP1, ~] = sort(reshapedSP1);
[sortedSM1, sortedIndexSM1] = sort(reshapedSM1);
[sortedMix, sortedIndexMix] = sort(reshapedMix);
m  = payload * (nnz(jpeg_dct) - nnz(jpeg_dct(1:8:sizeImg(1),1:8:sizeImg(2))));
%[y, p1Pq, m1Pq] =  EmbeddingSimulator(jpeg_dct, rhop1Real, rhom1Real, m);
%distortionReal = sum(sum(p1Pq.*rhop1Real) + sum(m1Pq .* rhom1Real));
%[y, p1O, m1O] =  EmbeddingSimulator(jpeg_dct, rhoP1, rhoM1, m);
%distortionO = sum(sum(p1O.*rhop1Real) + sum(m1O .* rhom1Real));
diff_round = pr - round(pr);
rhoP1Copy = rhoP1;
rhoM1Copy = rhoM1;
rightNum = 0;
allNum = 0;
b = 1;
lenChange = round(lenImg * b);
a = 0.65;
c = 0;
rhoP1 = rhoP1Copy;
rhoM1 = rhoM1Copy;
rightNum = 0;
allNum = 0;
if(usePredict)
    for i=1:lenChange
        index = sortedIndex(i);
        if( abs(diff_round(index)) > c)
            allNum = allNum + 1;
            if preDirection(index)>0  
                if(rhop1Real(index) < rhom1Real(index))
                    rightNum = rightNum + 1;
                end
                rhoP1(index) = rhoP1(index) * a;
            elseif preDirection(index)<0
                if(rhop1Real(index) > rhom1Real(index))
                    rightNum = rightNum + 1;
                end
                rhoM1(index) = rhoM1(index) * a;
            end
        end
    end
end
rng(randkey);
randPerm = randperm(lenImg);
jpeg_y_perm = int32(jpeg_dct(randPerm));
jpegdct_row = jpeg_dct(1:length(randPerm));
rhoP1_perm = rhoP1(randPerm);
rhoM1_perm = rhoM1(randPerm);
%rhoP1_perm = rhoP1Copy(randPerm);
%rhoM1_perm = rhoM1Copy(randPerm);
rho = zeros(3,lenImg,'single');
rho(1,:) = rhoM1_perm;
rho(3,:) = rhoP1_perm;
nzac = uint32(payload * (nnz(jpeg_dct) - nnz(jpeg_dct(1:8:sizeImg(1),1:8:sizeImg(2)))));
rng(randkey);
msg_embeded = uint8(round(rand([1, nzac])));
for times = 1:10
     try
        [D stego, n_msg_bits l] = stc_pm1_pls_embed(jpeg_y_perm, rho, msg_embeded, 7);
        break;
     catch
         if times == 10
             throw("error");
         end
         continue;
     end
end
    
for i=1:lenImg
            stego_real(randPerm(i)) = stego(i);
end
stego_real2 = reshape(stego_real, sizeImg);
jpeg_struct.coef_arrays{1} = double(stego_real2);
%jpeg_write(jpeg_struct, stegoName);
num = nnz(double(stego_real2) - jpeg_dct);
diff = double(stego_real2) - jpeg_dct;
diff = reshape(diff, [length(diff(:)),1]);
positionMix = zeros([length(diff)*2,1]);
maxIndex = 0;
indexArr = [];
indexArrIndex = 1;
for i = 1:length(diff)*2
    index = sortedIndexMix(i); 
    if(index>length(diff))
        index2 = index - length(diff);
        if(diff(index2) == -1)
           positionMix(i) = 1;
           indexArr(indexArrIndex) = i;
           indexArrIndex =  indexArrIndex + 1;
           maxIndex = i;
        end
    else
        if(diff(index) == 1)
           positionMix(i) = 1; %the real modification point in side domain
           indexArr(indexArrIndex) = i;
           indexArrIndex =  indexArrIndex + 1;
           maxIndex = i;
        end
    end
end

for i = 1:length(diff)
    index = sortedIndex(i); 
    
        if(diff(index) ~= 0)
         
           maxIndexReal = i;
        end
    
end


resultAll65 = nnz(positionMix);
resultAll = nnz(positionMix);
thresholdNum = round(0.0023*2 * resultAll);
areaTest = 0.1*length(positionMix);
maxRatio = maxIndex / length(positionMix(:));
maxRatio2 = max(floor(maxRatio*100/5)*5/100,0.15);
maxRatio3 = maxIndexReal / length(diff);
maxRatio2 = max(maxRatio,0.2);
maxIndex2 = indexArr(length(indexArr) - thresholdNum);
%maxIndex2 = max(maxIndex2, maxIndex - areaTest);
location_all2 = floor(t_max * length(positionMix));
ratio = maxIndex / location_all2;
step1 = location_all2 / folderNum;
%location_all = floor(maxIndex/1.1567);
if ratio >1 
    test = 1;
    %ratio
end
location_all = location_all2;
%{
if ratio>base
    location_all = location_all2;
else
    ratio = base;
    location_all = floor(maxIndex/(base));
    %stepSize = maxIndex - location_all;
    %folderNum = ceil(location_all / stepSize);
end
%}
base = 1.5;
timer = 1;
while 1
    location_all2 = floor(t_max * length(positionMix));
    step1 = location_all2 / folderNum;
    ratio = base;
    location_all = floor(maxIndex/(base));
    N2 = floor(location_all / step1);
    folderLen_step = floor( theMax * 10000 / (folderNum+1));
    folderLen_step = double(folderLen_step) / 10000;
    location_step = floor(location_all / (N2));
    %location_all = location_all2;
    diffNumInFolder = [];
    diffRatio = [];
    startIndex = 0;
    endIndex = 0;
    for i=1:N2-1
        startIndex = location_all - (i) * location_step + 1; 
        endIndex = location_all - (i - 1) * location_step;
        diffNumInFolder(N2 -i +1) = nnz(positionMix(startIndex:endIndex));
    
    end
    if N2>=1
        if startIndex == 0
            endIndex = location_all;
        else
            
            endIndex = startIndex - 1;
        end
        startIndex = 1;
        diffNumInFolder(1) = nnz(positionMix(startIndex:endIndex));
        
        endIndex = location_all;
    end
    numberAbove0_2 = nnz(positionMix(endIndex+1:length(positionMix)));
    diffNumInFolder = [diffNumInFolder, numberAbove0_2];
    diffNumStd = diffNumInFolder ./ resultAll;
    if(length(diffNumInFolder)==1)
        break;
    end
    if diffNumInFolder(length(diffNumInFolder))/diffNumInFolder(length(diffNumInFolder)-1) < newratio
        base = base + 0.1;
        timer = timer + 1;
        if(timer == 10)
            break;
        end
    else
        break;
    end
end
diffNumInFolder;
number65 = diffNumInFolder;
diffNumStd = diffNumInFolder ./ resultAll;



    resultAll = nnz(positionMix);
    result1 = nnz(positionMix(1:round(0.05*length(sortedIndexMix))));
    result2 = nnz(positionMix(round(0.05*length(sortedIndexMix)):round(0.1*length(sortedIndexMix))));
    result3 = nnz(positionMix(round(0.1*length(sortedIndexMix)):round(0.15*length(sortedIndexMix))));
    result4 = nnz(positionMix(round(0.15*length(sortedIndexMix)):round(0.2*length(sortedIndexMix))));
    result5 = nnz(positionMix(round(0.2*length(sortedIndexMix)):round(0.3*length(sortedIndexMix))));
    result6 = nnz(positionMix(round(0.3*length(sortedIndexMix)):round(1*length(sortedIndexMix))));
    result7 = nnz(positionMix(round(0.2*length(sortedIndexMix)):1*length(sortedIndexMix)));
    result8 = nnz(positionMix(round(0.15*length(sortedIndexMix)):1*length(sortedIndexMix)));

    result11 = nnz(positionMix(1:round(0.025*length(sortedIndexMix))));
    result1_1 = nnz(positionMix(round(0.025*length(sortedIndexMix)): round(0.05*length(sortedIndexMix))));
    result21 = nnz(positionMix(round(0.05*length(sortedIndexMix)):round(0.075*length(sortedIndexMix))));
    result2_1 = nnz(positionMix(round(0.075*length(sortedIndexMix)):round(0.1*length(sortedIndexMix))));
    result31 = nnz(positionMix(round(0.1*length(sortedIndexMix)):round(0.125*length(sortedIndexMix))));
    result3_1 = nnz(positionMix(round(0.125*length(sortedIndexMix)):round(0.15*length(sortedIndexMix))));
    result41 = nnz(positionMix(round(0.15*length(sortedIndexMix)):round(0.175*length(sortedIndexMix))));
    result4_1 = nnz(positionMix(round(0.175*length(sortedIndexMix)):round(0.2*length(sortedIndexMix))));
    new_resultratio65 = [resultAll, result11, result1_1, result21, result2_1, result31, result3_1, result41,result4_1, result7]


%1- 10 - 100 - 1000 - 10000
cost65 = 0;
multiple = (1:N2);
%multiple2 = 10.^(folderLen_step * (multiple-1));

for i=N2:-1:1
    if(folderNum - (N2 - i) < 1)
        timer = 0;
    else
        timer = folderNum - (N2 - i);
    end
    cost65 = cost65 + diffNumStd(i) * 10^(timer * folderLen_step);
    
    observe(i) = 10^(timer * folderLen_step);
end
cost65 = cost65 + diffNumStd(N2 + 1) * 10^theMax ;
%cost65 = cost65 / nnz(positionMix);
%{
cost65 = 0;
multiple = (1:N2);
%multiple2 = 10.^(folderLen_step * (multiple-1));
for i=1:N2
    cost65 = cost65 + diffNumStd(i) * 10^(folderLen_step * (i));
    observe(i) = 10^(folderLen_step * (i));
end
cost65 = cost65 + diffNumStd(N2 + 1) * 10^theMax ;
%}

%获取普通嵌入的cost

rhoP1_perm = rhoP1Copy(randPerm);
rhoM1_perm = rhoM1Copy(randPerm);
%rhoP1_perm = rhoP1Copy(randPerm);
%rhoM1_perm = rhoM1Copy(randPerm);
rho = zeros(3,lenImg,'single');
rho(1,:) = rhoM1_perm;
rho(3,:) = rhoP1_perm;
nzac = uint32(payload * (nnz(jpeg_dct) - nnz(jpeg_dct(1:8:sizeImg(1),1:8:sizeImg(2)))));
rng(randkey);
msg_embeded = uint8(round(rand([1, nzac])));
for times = 1:10
     try
        [D stego, n_msg_bits l] = stc_pm1_pls_embed(jpeg_y_perm, rho, msg_embeded, 7);
        break;
     catch
         if times == 10
             throw("error");
         end
         continue;
     end
end

for i=1:lenImg
            stego_real(randPerm(i)) = stego(i);
end
stego_real2 = reshape(stego_real, sizeImg);
 diff = double(stego_real2) - jpeg_dct;
    diff = reshape(diff, [length(diff(:)),1]);
    positionMix = zeros([length(diff)*2,1]);
    for i = 1:length(diff)*2
        index = sortedIndexMix(i); 
        if(index>length(diff))
            index2 = index - length(diff);
            if(diff(index2) == -1)
               positionMix(i) = 1;
            end
        else
            if(diff(index) == 1)
               positionMix(i) = 1; %the real modification point in side domain
            end
        end
    end
    resultAllTemp = nnz(positionMix);
    resultAll = nnz(positionMix);

    diffNumInFolder = [];
    diffRatio = [];
    startIndex = 0;
    endIndex = 0;
    for i=1:N2-1
        startIndex = location_all - (i) * location_step + 1; 
        endIndex = location_all - (i - 1) * location_step;
        diffNumInFolder(N2 -i +1) = nnz(positionMix(startIndex:endIndex));

    end
    if N2>=1
        if startIndex == 0
            endIndex = location_all;
        else

            endIndex = startIndex - 1;
        end
        startIndex = 1;
        diffNumInFolder(1) = nnz(positionMix(startIndex:endIndex));

        endIndex = location_all;
    end
    numberAbove0_2 = nnz(positionMix(endIndex + 1:length(positionMix)));

    diffNumInFolder = [diffNumInFolder, numberAbove0_2];
    diffNumStd = diffNumInFolder ./ resultAll;
    diffNumStdLSB  = diffNumStd;
    len = length(multiple);

    costLSB = 0;
    for i=N2:-1:1
        if(folderNum - (N2 - i) < 1)
            timer = 0;
        else
            timer = folderNum - (N2 - i);
        end
        costLSB  = costLSB + diffNumStd(i) * 10^(timer * folderLen_step);

        observe(i) = 10^(timer * (i));
    end
    costLSB = costLSB + diffNumStd(N2 + 1) * 10^theMax ;

    numLSB = resultAll;
 costRatioMY = costLSB / cost65
costRatioMY = costLSB - cost65;

diffNumInFolder65 = diffNumInFolder;
a_array = [0.6:0.05:0.8];
%a_array = [0.6];
%b_array = [maxRatio2-0.1:0.05:maxRatio2+0.1]
%b_array = [max(maxRatio2-0.2,0.1):0.05:max((maxRatio2+0.05),0.3)]
b_array = [max(maxRatio2-0.2,0.1):0.05:max((maxRatio2+0.05),0.3)]
%b_array = [0.1:0.05:0.3];
%a_array = [0.65];
%b_array = [1];
c_array = [0];
smallestDis = 0;
smallA = -1;
smallC = -1;
resultTemp = zeros(length(a_array), length(b_array),length(c_array));
for iii = 1:length(b_array)
b = b_array(iii);
lenChange = round(lenImg * b);
for ii = 1:length(a_array)
    for jj = 1:length(c_array)
        a = a_array(ii);
        c = c_array(jj);
        rhoP1 = rhoP1Copy;
        rhoM1 = rhoM1Copy;
        rightNum = 0;
        allNum = 0;
        if(usePredict)
            for i=1:lenChange
                index = sortedIndex(i);
                if( abs(diff_round(index)) > c)
                    allNum = allNum + 1;
                    if preDirection(index)>0  
                        if(rhop1Real(index) < rhom1Real(index))
                            rightNum = rightNum + 1;
                        end
                        rhoP1(index) = rhoP1(index) * a;
                    elseif preDirection(index)<0
                        if(rhop1Real(index) > rhom1Real(index))
                            rightNum = rightNum + 1;
                        end
                        rhoM1(index) = rhoM1(index) * a;
                    end
                end
            end
        end
        %[y, p1A, m1A] =  EmbeddingSimulator(jpeg_dct, rhoP1, rhoM1, m);
        %distortionA = sum(sum(p1A.*rhop1Real) + sum(m1A .* rhom1Real));
        rng(randkey);
        randPerm = randperm(lenImg);
        jpeg_y_perm = int32(jpeg_dct(randPerm));
        jpegdct_row = jpeg_dct(1:length(randPerm));
        rhoP1_perm = rhoP1(randPerm);
        rhoM1_perm = rhoM1(randPerm);
        %rhoP1_perm = rhoP1Copy(randPerm);
        %rhoM1_perm = rhoM1Copy(randPerm);
        rho = zeros(3,lenImg,'single');
        rho(1,:) = rhoM1_perm;
        rho(3,:) = rhoP1_perm;
        nzac = uint32(payload * (nnz(jpeg_dct) - nnz(jpeg_dct(1:8:sizeImg(1),1:8:sizeImg(2)))));
        rng(randkey);
        msg_embeded = uint8(round(rand([1, nzac])));
        for times = 1:10
             try
                [D stego, n_msg_bits l] = stc_pm1_pls_embed(jpeg_y_perm, rho, msg_embeded, 7);
                break;
             catch
                 if times == 10
                     throw("error");
                 end
                 continue;
             end
        end
        %[D stego, n_msg_bits l] = stc_pm1_pls_embed(jpeg_y_perm, rho, msg_embeded, 7);
        for i=1:lenImg
            stego_real(randPerm(i)) = stego(i);
        end

        stego_real2 = reshape(stego_real, sizeImg);
        diff = double(stego_real2) - jpeg_dct;
        diff = reshape(diff, [length(diff(:)),1]);
        positionMix = zeros([length(diff)*2,1]);
        for i = 1:length(diff)*2
            index = sortedIndexMix(i); 
            if(index>length(diff))
                index2 = index - length(diff);
                if(diff(index2) == -1)
                   positionMix(i) = 1;
                end
            else
                if(diff(index) == 1)
                   positionMix(i) = 1; %the real modification point in side domain
                end
            end
        end
        resultAllTemp = nnz(positionMix);
        resultAll = nnz(positionMix);
        %folderLen_step = floor( theMax * 10000 / folderNum);
        %folderLen_step = double(folderLen_step) / 10000;
        %location_all = floor(t_max * length(positionMix));
        %location_step = floor(location_all / folderNum);
        diffNumInFolder = [];
        diffRatio = [];
        startIndex = 0;
        endIndex = 0;
        for i=1:N2-1
            startIndex = location_all - (i) * location_step + 1; 
            endIndex = location_all - (i - 1) * location_step;
            diffNumInFolder(N2 -i +1) = nnz(positionMix(startIndex:endIndex));

        end
        if N2>=1
            if startIndex == 0
                endIndex = location_all;
            else

                endIndex = startIndex - 1;
            end
            startIndex = 1;
            diffNumInFolder(1) = nnz(positionMix(startIndex:endIndex));

            endIndex = location_all;
        end
        numberAbove0_2 = nnz(positionMix(endIndex + 1:length(positionMix)));
       
        diffNumInFolder = [diffNumInFolder, numberAbove0_2];
        diffNumStd = diffNumInFolder ./ resultAll;
        len = length(multiple);
        
        cost = 0;
        for i=N2:-1:1
            if(folderNum - (N2 - i) < 1)
                timer = 0;
            else
                timer = folderNum - (N2 - i);
            end
            cost = cost + diffNumStd(i) * 10^(timer * folderLen_step);

            observe(i) = 10^(timer * (i));
        end
        cost = cost + diffNumStd(N2 + 1) * 10^theMax ;
        %cost = cost / nnz(positionMix);
        
        
        costIncrease =   (cost65 - cost);
    
    
        
        %numberIncrease2(numberIncrease2<0.5) = 0.5;
         %{
        newcost = costIncrease - numberIncrease;
        if (newcost > smallestDis)
            smallestDis = newcost;
            smallA = a;
            smallC = c;
            smallB = b;
            smallallNum = resultAll;
            costIncreaseS = costIncrease;
            numberIncreaseS =  numberIncrease;
            smallDic = [resultAll, result1, result2, result3, result4, result5, result6, result7,result8];
        end
        %}
        costarr(ii,iii,jj) = (costLSB - cost)*costRatioMY;
        costIncreaseTemp(ii,iii,jj) = (cost65 - cost)*costRatioMY;
        %costIncreaseTemp2(ii,iii,jj) = costIncrease2;
    
     
        numberar(ii,iii,jj) = resultAllTemp;
      
        end
    end
end

for i=1:length(a_array)
    
    costRatio(i,:) = costIncreaseTemp(i,:) ./ numberar(i,:);  %increase cost for every increased number
    %costRatio(i,:) = costIncreaseTemp(i,:);
end
for i=1:length(a_array)
   
    costRatiostd(i,:) = (costRatio(i,:)-mean(costRatio(:)))/(std(costRatio(:)) + 10^(-12));
    
    numberIncreaseTemp2std(i, :) = (numberar(i,:)-mean(numberar(:)))/(std(numberar(:)) + 10^(-12));
end




bigCost = -inf;



p = [1,0];
k_array = [0, 5, 10];
k_len = length(k_array);

%k = k_array(k_index);
   
    
     for ii = 1:length(a_array)
        for jj = 1:length(b_array)
            %cost =  pa*costIncreaseTempstd(ii,jj) - (1-pa)*numberIncreaseTempstd(ii,jj); 
            %cost = costRatio(ii,jj); 
            cost = pa * costRatiostd(ii,jj) - (1-pa) * numberIncreaseTemp2std(ii,jj);
            %cost = costarr(ii,jj) ;
            %cost = pa * costRatio2(ii,jj) - (1-pa) * numberstd(ii,jj);
            if (cost > bigCost)
                tempCostIncreaseTempstd = costRatiostd(ii,jj);
                tempNumberIncreaseTempstd =  numberIncreaseTemp2std(ii,jj);
                a_temp = a_array(ii);
                b_temp = b_array(jj);
                ii_temp = ii;
                jj_array = jj;
                bigCost = cost;
            end
        end
     end
    
    %fprintf(fid, 'the biggest cost is  %f\n', bigCost);
    %{
    if(allNumber < smallallNum)
        b = 1;
        lenChange = round(lenImg * b);
        a = 0.65;
        c = 0;

    else
        b = smallB;
        lenChange = round(lenImg * b);
        a = smallA;
        c = smallC;
    end
    %} 
    try
        b = b_temp
    catch
        test  = 1;
    end
    lenChange = round(lenImg * b);
    a = a_temp
    %fprintf(fid, 'the a is %f\n', a);
    %fprintf(fid, 'the b is %f\n', b);
    rhoP1 = rhoP1Copy;
    rhoM1 = rhoM1Copy;
    rightNum = 0;
    allNum = 0;
    if(usePredict)
        for i=1:lenChange
            index = sortedIndex(i);
            if( abs(diff_round(index)) > c)
                allNum = allNum + 1;
                if preDirection(index)>0  %鑴楅簱鑴欓瞾鑴欓垾婧嶅叄?0鑴楀崵鑴欓鑴欒墿鑴楁埉鑴欓垾婧嶅伄纬鍋鍏ゆ崡鍏熷緷鍏熻鍐??鎳婂厽寰濆叝鍠㈠伄鈭跺啠?鈷氬厽?
                    if(rhop1Real(index) < rhom1Real(index))
                        rightNum = rightNum + 1;
                    end
                    rhoP1(index) = rhoP1(index) * a;
                elseif preDirection(index)<0
                    if(rhop1Real(index) > rhom1Real(index))
                        rightNum = rightNum + 1;
                    end
                    rhoM1(index) = rhoM1(index) * a;
                end
            end
        end
    end
    rng(randkey);
    randPerm = randperm(lenImg);
    jpeg_y_perm = int32(jpeg_dct(randPerm));
    jpegdct_row = jpeg_dct(1:length(randPerm));
    if(usePredict)
        rhoP1_perm = rhoP1(randPerm);
        rhoM1_perm = rhoM1(randPerm);
    else
        rhoP1_perm = rhoP1Copy(randPerm);
        rhoM1_perm = rhoM1Copy(randPerm);
    end
    %rhoP1_perm = rhoP1Copy(randPerm);
    %rhoM1_perm = rhoM1Copy(randPerm
    
    
    
    
    
    
    
    rho = zeros(3,lenImg,'single');
    
    
    
    rho(1,:) = rhoM1_perm;
    rho(3,:) = rhoP1_perm;
    nzac = uint32(payload * (nnz(jpeg_dct) - nnz(jpeg_dct(1:8:sizeImg(1),1:8:sizeImg(2)))));
    rng(randkey);
    msg_embeded = uint8(round(rand([1, nzac])));
    
    [D stego, ~, l] = stc_pm1_pls_embed(jpeg_y_perm, rho, msg_embeded, 7);
            
            
    for i=1:lenImg
                stego_real(randPerm(i)) = stego(i);
    end
    stego_real2 = reshape(stego_real, sizeImg);
    jpeg_struct.coef_arrays{1} = double(stego_real2);
    jpeg_write(jpeg_struct, stegoName);
    num = nnz(double(stego_real2) - jpeg_dct);
    diff = double(stego_real2) - jpeg_dct;
    diff = reshape(diff, [length(diff(:)),1]);
    positionMix = zeros([length(diff)*2,1]);
    for i = 1:length(diff)*2
        index = sortedIndexMix(i); %鑴楀崵鑴欐紡鑴欓埀顑炲厽濂藉叅鎹楀伄妫靛啠?娅伄骞诲伄璇ュ厽鐫瑰厽鎯峰叄涔呭伄璇ュ啠?鐏诲伄寰楀厽?
        if(index>length(diff))
            index2 = index - length(diff);
            if(diff(index2) == -1)
               positionMix(i) = 1;
            end
        else
            if(diff(index) == 1)
               positionMix(i) = 1; %the real modification point in side domain
            end
        end
    end
     resultAllTemp = nnz(positionMix);
    resultAll = nnz(positionMix);
    %location_all = floor(t_max * length(positionMix));
    %location_step = floor(location_all / folderNum);
    diffNumInFolder = [];
    diffRatio = [];
    startIndex = 0;
    endIndex = 0;
    for i=1:N2-1
        startIndex = location_all - (i) * location_step + 1; 
        endIndex = location_all - (i - 1) * location_step;
        diffNumInFolder(N2 -i +1) = nnz(positionMix(startIndex:endIndex));
    
    end
    if N2>=1
        if startIndex == 0
            endIndex = location_all;
        else
            
            endIndex = startIndex - 1;
        end
        startIndex = 1;
        diffNumInFolder(1) = nnz(positionMix(startIndex:endIndex));
        
        endIndex = location_all;
    end
    numberAbove0_2 = nnz(positionMix(endIndex+1:length(positionMix)));
    
    diffNumInFolder = [diffNumInFolder, numberAbove0_2];
    numberbest = diffNumInFolder;
    resultAll = nnz(positionMix);
    result1 = nnz(positionMix(1:round(0.05*length(sortedIndexMix))));
    result2 = nnz(positionMix(round(0.05*length(sortedIndexMix)):round(0.1*length(sortedIndexMix))));
    result3 = nnz(positionMix(round(0.1*length(sortedIndexMix)):round(0.15*length(sortedIndexMix))));
    result4 = nnz(positionMix(round(0.15*length(sortedIndexMix)):round(0.2*length(sortedIndexMix))));
    result5 = nnz(positionMix(round(0.2*length(sortedIndexMix)):round(0.3*length(sortedIndexMix))));
    result6 = nnz(positionMix(round(0.3*length(sortedIndexMix)):round(1*length(sortedIndexMix))));
    result7 = nnz(positionMix(round(0.2*length(sortedIndexMix)):1*length(sortedIndexMix)));
    result8 = nnz(positionMix(round(0.15*length(sortedIndexMix)):1*length(sortedIndexMix)));
    
    result11 = nnz(positionMix(1:round(0.025*length(sortedIndexMix))));
    result1_1 = nnz(positionMix(round(0.025*length(sortedIndexMix)): round(0.05*length(sortedIndexMix))));
    result21 = nnz(positionMix(round(0.05*length(sortedIndexMix)):round(0.075*length(sortedIndexMix))));
    result2_1 = nnz(positionMix(round(0.075*length(sortedIndexMix)):round(0.1*length(sortedIndexMix))));
    result31 = nnz(positionMix(round(0.1*length(sortedIndexMix)):round(0.125*length(sortedIndexMix))));
    result3_1 = nnz(positionMix(round(0.125*length(sortedIndexMix)):round(0.15*length(sortedIndexMix))));
    result41 = nnz(positionMix(round(0.15*length(sortedIndexMix)):round(0.175*length(sortedIndexMix))));
    result4_1 = nnz(positionMix(round(0.175*length(sortedIndexMix)):round(0.2*length(sortedIndexMix))));
    new_resultratio = [resultAll, result11, result1_1, result21, result2_1, result31, result3_1, result41,result4_1, result7]
    result1r = result1/resultAll;
    result2r = result2/resultAll;
    result3r = result3/resultAll;
    result4r = result4/resultAll;
    result7r = result7/resultAll;
    costNew = base_factor^0*result7r + base_factor^(-2)*result4r + base_factor^(-4)*result3r + base_factor^(-6) * result2r + base_factor^(-8) * result1r;
    %cost = 10^0*result7r + 10^(-1)*result4r + 10^(-2)*result3r + 10^(-3) * result2r + 10^(-4) * result1r;
    %cost = 10^0*result7r + 10^(-2)*result4r + 10^(-4)*result3r ;
    %cost = 0.7*result7 + 0.20*result4 + 0.08*result3 + 0.00906942 * resultAll;
   % smallDicNew = [resultAll, result1, result2, result3, result4, result5, result6, result7,result8]
   %new_resultratio = [resultAll, result11, result1_1, result21, result2_1, result31, result3_1, result41,result4_1, result7]
   smallDicNew = [resultAll, result1, result2, result3, result4, result7];
    sameIndex = 0;

    for i=1:length(diff(:))
        if(diff(i)==1 && preDirection(i)==1)
            sameIndex = sameIndex+1;
        elseif(diff(i)==-1 && preDirection(i)==-1)
            sameIndex = sameIndex+1;
        else
        end

    end
    ratio = sameIndex / nnz(diff(:));
    fclose(fid);
end